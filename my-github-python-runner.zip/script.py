print("Hello from GitHub Actions! This script is running successfully.")
