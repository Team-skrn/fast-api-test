# GitHub Python Runner

This repository contains a setup to run a Python script automatically using GitHub Actions.

## How to Use

1. **Upload this project to GitHub**.
2. **Push changes** to trigger the GitHub Action.
3. **View results** in the Actions tab.

## Files

- **script.py** → The Python script that runs.
- **requirements.txt** → Dependencies (if needed).
- **.github/workflows/python-script.yml** → GitHub Actions workflow.

Happy Coding! 🚀
